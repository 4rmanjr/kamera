/**
 * Location Service Module
 * Mengelola fungsionalitas geolokasi
 */

export class LocationService {
    constructor({ state, dom, eventBus }) {
        this.state = state;
        this.dom = dom;
        this.eventBus = eventBus;
    }

    init() {
        if ("geolocation" in navigator) {
            this.state.watchId = navigator.geolocation.watchPosition(
                (p) => {
                    this.state.location = { 
                        lat: p.coords.latitude.toFixed(6), 
                        lng: p.coords.longitude.toFixed(6), 
                        acc: Math.round(p.coords.accuracy) 
                    };
                    this.dom.lblGeo.innerHTML = `<i class="ph ph-map-pin text-blue-400" aria-hidden="true"></i> ${this.state.location.lat}, ${this.state.location.lng} (±${this.state.location.acc}m)`;
                    this.dom.lblGeo.onclick = null;
                    
                    // Emit event bahwa lokasi telah diperbarui
                    this.eventBus.emit('location:updated', this.state.location);
                },
                (err) => {
                    this.dom.lblGeo.innerHTML = `<i class="ph ph-warning text-red-400" aria-hidden="true"></i> GPS Error (Tap untuk Ulang)`;
                    this.dom.lblGeo.onclick = () => { 
                        this.dom.lblGeo.innerHTML = `<i class="ph ph-spinner animate-spin mr-1" aria-hidden="true"></i> Mencari GPS...`; 
                        this.init(); 
                    };
                },
                { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }
            );
        } else { 
            this.dom.lblGeo.innerText = "GPS Tidak Didukung"; 
        }
    }
}